let fs = require('fs');
let RecofW20JsonGenerator = require('./generator/frontend/RecofW20JsonGenerator');

let parameters = {};

process.argv.forEach(function (val, index, array) {
	if(val.indexOf("--") == 0){
  		parameters[val.split("=")[0].replace("--","")] = val.split("=")[1];
  	}
});


//var filePaths = JSON.parse(fs.readFileSync('./manifests/template.paths.json').toString());

// Main Manifest
let manifest = JSON.parse(fs.readFileSync('./manifests/' + parameters["id"] + '.json').toString());


let recofW20JsonGenerator = new RecofW20JsonGenerator(manifest);
recofW20JsonGenerator.render();

