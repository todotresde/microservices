module.exports = {
	"paths": {
		"recof.w20.json": {
			"template" : "./templates/frontend/recof.w20.json.mustache",
			"build" : "/desWeb/src/main/resources/META-INF/resources/recof"
		},
		"entity.html": {
			"template" : "./templates/frontend/views/entity.html.mustache",
			"build" : "./templates/frontend/views/entity.html.mustache"
		},
		"form.html": {
			"template" : "./templates/frontend/views/form.html.mustache",
			"build": "./templates/frontend/views/form.html.mustache"
		},
		"list.html": {
			"template": "./templates/frontend/views/list.html.mustache",
			"build": "./templates/frontend/views/list.html.mustache"
		},
		"search.html": {
			"template": "./templates/frontend/views/search.html.mustache",
			"build": "./templates/frontend/views/search.html.mustache"
		},
		"entity.js": {
			"template": "./templates/frontend/modules/entity.js.mustache",
			"build": "./templates/frontend/modules/entity.js.mustache"
		},
		"entity.render.js": {
			"template": "./templates/frontend/modules/entity.render.js.mustache",
			"build": "./templates/frontend/modules/entity.render.js.mustache",
		},
		"entity.service.js": {
			"template": "./templates/frontend/modules/entity.service.js.mustache",
			"build": "./templates/frontend/modules/entity.service.js.mustache"
		},
		"entity.java": {
			"template": "./templates/backend/desDomain/com/inetpsa/des/domain/entity/entity.java.mustache",
			"build": "./templates/backend/desDomain/com/inetpsa/des/domain/entity/entity.java.mustache"
		},
		"entityService.java": {
			"template": "./templates/backend/desDomain/com/inetpsa/des/service/entity/entity.java.mustache",
			"build": "./templates/backend/desDomain/com/inetpsa/des/service/entity/entity.java.mustache"
		},
		"entityRepresentation.java": {
			"template": "./templates/backend/desWeb/com/inetpsa/des/domain/entity/entityRepresentation.java.mustache",
			"build": "./templates/backend/desWeb/com/inetpsa/des/domain/entity/entityRepresentation.java.mustache"
		},
		"entitySearchRepresentation.java": {
			"template": "./templates/backend/desWeb/com/inetpsa/des/domain/entity/entitySearchRepresentation.java.mustache",
			"build": "./templates/backend/desWeb/com/inetpsa/des/domain/entity/entitySearchRepresentation.java.mustache"
		},
		"entityFinder.java": {
			"template": "./templates/backend/desWeb/com/inetpsa/des/finder/entity/entityFinder.java.mustache",
			"build": "./templates/backend/desWeb/com/inetpsa/des/finder/entity/entityFinder.java.mustache",
		},
		"entityFinderImpl.java": {
			"template": "./templates/backend/desWeb/com/inetpsa/des/finder/entity/entityFinderImpl.java.mustache",
			"build": "./templates/backend/desWeb/com/inetpsa/des/finder/entity/entityFinderImpl.java.mustache",
		},
		"entityResource.java": {
			"template": "./templates/backend/desWeb/com/inetpsa/des/rest/entity/entityResource.java.mustache",
			"build": "./templates/backend/desWeb/com/inetpsa/des/rest/entity/entityResource.java.mustache",
		}
	}
};