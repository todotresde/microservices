'use strict';
let Mustache = require('mustache');
let fs = require('fs-extra');

module.exports = class Generator {
	constructor(manifest) {
		this.manifest = manifest;
	}

	render() {
		var path = "./builds/" + this.manifest.id + this.buildPath;
		var render = Mustache.render(fs.readFileSync(this.templatePath).toString(), this.processManifest());
		
		fs.ensureDirSync(path);	
		fs.writeFileSync(path + this.id, render);
	}

	processManifest() {
		return this.manifest;
	}
}