'use strict';

module.exports = class formHTML {
	constructor() {
	}

}