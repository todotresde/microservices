'use strict';

module.exports = class entityServiceJS {
	constructor() {
	}

}