'use strict';

let Generator = require('../Generator');
let Constants = require('../Constants');

module.exports = class RecofW20JsonGenerator extends Generator{
	constructor(manifest) {
		super(manifest);
		this.id = "recof.w20.json";
		this.templatePath = Constants.paths[this.id].template;
		this.buildPath = Constants.paths[this.id].build;
	}

	render() {
		super.render();
	}
}