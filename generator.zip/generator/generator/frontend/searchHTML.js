'use strict';

module.exports = class searchHTML {
	constructor() {
	}

}