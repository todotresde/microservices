'use strict';

module.exports = class entityRenderJS {
	constructor() {
	}

}