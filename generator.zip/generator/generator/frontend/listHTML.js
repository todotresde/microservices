'use strict';

module.exports = class listHTML {
	constructor() {
	}

}