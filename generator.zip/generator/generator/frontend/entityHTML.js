'use strict';

module.exports = class entityHTML {
	constructor() {
	}

}