'use strict';

module.exports = class entityJS {
	constructor() {
	}

}