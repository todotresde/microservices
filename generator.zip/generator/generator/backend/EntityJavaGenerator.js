'use strict';

let Generator = require('./Generator');

module.exports = class EntityJavaGenerator extends Generator{
	constructor(manifest) {
		super(manifest);
		this.templatePath = "./templates/backend/recof.w20.json.mustache";
		this.exportPath = "/recof.w20.json";
	}

	render() {
		super.render();
	}
}